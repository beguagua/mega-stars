# Guia de Otimização - Mega Stars

## Otimizações de Performance Implementadas

### 1. Otimizações Gráficas

#### Level of Detail (LOD)
```csharp
// Implementar LOD para personagens distantes
public class BrawlerLOD : MonoBehaviour
{
    public GameObject highDetailModel;
    public GameObject lowDetailModel;
    public float lodDistance = 20f;
    
    void Update()
    {
        float distanceToCamera = Vector3.Distance(transform.position, Camera.main.transform.position);
        
        if (distanceToCamera > lodDistance)
        {
            highDetailModel.SetActive(false);
            lowDetailModel.SetActive(true);
        }
        else
        {
            highDetailModel.SetActive(true);
            lowDetailModel.SetActive(false);
        }
    }
}
```

#### Object Pooling para Projéteis
```csharp
public class ProjectilePool : MonoBehaviour
{
    public GameObject projectilePrefab;
    public int poolSize = 50;
    
    private Queue<GameObject> projectilePool = new Queue<GameObject>();
    
    void Start()
    {
        for (int i = 0; i < poolSize; i++)
        {
            GameObject projectile = Instantiate(projectilePrefab);
            projectile.SetActive(false);
            projectilePool.Enqueue(projectile);
        }
    }
    
    public GameObject GetProjectile()
    {
        if (projectilePool.Count > 0)
        {
            GameObject projectile = projectilePool.Dequeue();
            projectile.SetActive(true);
            return projectile;
        }
        return Instantiate(projectilePrefab);
    }
    
    public void ReturnProjectile(GameObject projectile)
    {
        projectile.SetActive(false);
        projectilePool.Enqueue(projectile);
    }
}
```

#### Texture Streaming
- **Android:** Usar compressão ASTC para melhor qualidade/tamanho
- **iOS:** Usar compressão PVRTC para compatibilidade
- **PlayStation:** Usar compressão BC7 para alta qualidade

### 2. Otimizações de Código

#### Update Optimization
```csharp
public class OptimizedUpdate : MonoBehaviour
{
    private float updateInterval = 0.1f; // Atualizar a cada 100ms
    private float lastUpdate = 0f;
    
    void Update()
    {
        if (Time.time - lastUpdate >= updateInterval)
        {
            // Lógica que não precisa rodar todo frame
            UpdatePlayerStats();
            lastUpdate = Time.time;
        }
        
        // Lógica que precisa rodar todo frame
        HandleInput();
    }
}
```

#### Garbage Collection Optimization
```csharp
public class GCOptimized : MonoBehaviour
{
    // Evitar alocações desnecessárias
    private Vector3 cachedPosition;
    private StringBuilder stringBuilder = new StringBuilder();
    
    void Update()
    {
        // ❌ Ruim - cria garbage
        // string text = "Score: " + score.ToString();
        
        // ✅ Bom - reutiliza StringBuilder
        stringBuilder.Clear();
        stringBuilder.Append("Score: ");
        stringBuilder.Append(score);
        string text = stringBuilder.ToString();
    }
}
```

### 3. Otimizações de Rede

#### Delta Compression
```csharp
public class NetworkOptimization : MonoBehaviour
{
    private Vector3 lastSentPosition;
    private float positionThreshold = 0.1f;
    
    public void SendPositionUpdate()
    {
        Vector3 currentPosition = transform.position;
        
        // Só enviar se a posição mudou significativamente
        if (Vector3.Distance(currentPosition, lastSentPosition) > positionThreshold)
        {
            // Enviar apenas a diferença (delta)
            Vector3 deltaPosition = currentPosition - lastSentPosition;
            SendNetworkMessage(deltaPosition);
            lastSentPosition = currentPosition;
        }
    }
}
```

#### Adaptive Network Frequency
```csharp
public class AdaptiveNetworking : MonoBehaviour
{
    private float baseUpdateRate = 20f; // 20 updates por segundo
    private float currentUpdateRate;
    private float lastPing;
    
    void Start()
    {
        currentUpdateRate = baseUpdateRate;
    }
    
    void Update()
    {
        // Adaptar frequência baseada na latência
        if (lastPing < 50f)
            currentUpdateRate = baseUpdateRate;
        else if (lastPing < 100f)
            currentUpdateRate = baseUpdateRate * 0.8f;
        else
            currentUpdateRate = baseUpdateRate * 0.6f;
    }
}
```

### 4. Otimizações de Memória

#### Asset Streaming
```csharp
public class AssetStreaming : MonoBehaviour
{
    private Dictionary<string, Texture2D> loadedTextures = new Dictionary<string, Texture2D>();
    
    public void LoadTextureAsync(string textureName)
    {
        if (!loadedTextures.ContainsKey(textureName))
        {
            StartCoroutine(LoadTextureCoroutine(textureName));
        }
    }
    
    IEnumerator LoadTextureCoroutine(string textureName)
    {
        ResourceRequest request = Resources.LoadAsync<Texture2D>(textureName);
        yield return request;
        
        if (request.asset != null)
        {
            loadedTextures[textureName] = request.asset as Texture2D;
        }
    }
    
    public void UnloadUnusedTextures()
    {
        // Descarregar texturas não utilizadas
        Resources.UnloadUnusedAssets();
        System.GC.Collect();
    }
}
```

### 5. Otimizações Específicas por Plataforma

#### Android
```csharp
#if UNITY_ANDROID
public class AndroidOptimizations : MonoBehaviour
{
    void Start()
    {
        // Reduzir qualidade gráfica em dispositivos low-end
        if (SystemInfo.systemMemorySize < 3000) // Menos de 3GB RAM
        {
            QualitySettings.SetQualityLevel(0); // Qualidade baixa
            Application.targetFrameRate = 30;
        }
        else if (SystemInfo.systemMemorySize < 6000) // 3-6GB RAM
        {
            QualitySettings.SetQualityLevel(1); // Qualidade média
            Application.targetFrameRate = 45;
        }
        else // 6GB+ RAM
        {
            QualitySettings.SetQualityLevel(2); // Qualidade alta
            Application.targetFrameRate = 60;
        }
    }
}
#endif
```

#### iOS
```csharp
#if UNITY_IOS
public class iOSOptimizations : MonoBehaviour
{
    void Start()
    {
        // Otimizações específicas para iOS
        if (iPhone.generation == iPhoneGeneration.iPhone8 || 
            iPhone.generation == iPhoneGeneration.iPhone8Plus)
        {
            // Dispositivos mais antigos
            QualitySettings.SetQualityLevel(1);
            Application.targetFrameRate = 30;
        }
        else
        {
            // Dispositivos modernos
            QualitySettings.SetQualityLevel(2);
            Application.targetFrameRate = 60;
        }
    }
}
#endif
```

#### PlayStation
```csharp
#if UNITY_PS4 || UNITY_PS5
public class PlayStationOptimizations : MonoBehaviour
{
    void Start()
    {
        #if UNITY_PS5
        // Otimizações específicas para PS5
        QualitySettings.SetQualityLevel(3); // Qualidade máxima
        Application.targetFrameRate = 120;
        
        // Habilitar ray tracing se disponível
        if (SystemInfo.supportsRayTracing)
        {
            EnableRayTracing();
        }
        #elif UNITY_PS4
        // Otimizações para PS4
        QualitySettings.SetQualityLevel(2);
        Application.targetFrameRate = 60;
        #endif
    }
}
#endif
```

## Métricas de Performance Alvo

### Mobile (Android/iOS)
- **FPS:** 30-60 dependendo do hardware
- **RAM:** < 2GB
- **Bateria:** < 20% por hora
- **Carregamento:** < 10 segundos

### Console (PS4/PS5)
- **FPS:** 60 (PS4), 60-120 (PS5)
- **Resolução:** 1080p (PS4), 4K (PS5)
- **Carregamento:** < 5 segundos (PS4), < 2 segundos (PS5)

## Ferramentas de Profiling Recomendadas

### Unity Built-in
- Unity Profiler
- Frame Debugger
- Memory Profiler
- Network Profiler

### Platform-Specific
- **Android:** GPU Inspector, Systrace
- **iOS:** Xcode Instruments
- **PlayStation:** PlayStation SDK Profiler

## Checklist de Otimização

### Antes do Release
- [ ] Profiling completo em todas as plataformas
- [ ] Testes de stress com 6 jogadores simultâneos
- [ ] Verificação de vazamentos de memória
- [ ] Otimização de assets (texturas, áudio)
- [ ] Implementação de LOD em todos os modelos
- [ ] Object pooling para objetos frequentes
- [ ] Compressão de texturas adequada por plataforma
- [ ] Testes de performance em dispositivos low-end

### Monitoramento Contínuo
- [ ] Analytics de performance implementados
- [ ] Crash reporting configurado
- [ ] Métricas de FPS em tempo real
- [ ] Monitoramento de uso de memória
- [ ] Logs de performance de rede

