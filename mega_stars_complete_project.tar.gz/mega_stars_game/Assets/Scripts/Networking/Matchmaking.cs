using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Matchmaking : MonoBehaviour
{
    [Header("Matchmaking Settings")]
    public float searchTimeout = 30f;
    public int preferredPlayerCount = 6;
    public string gameMode = "GemGrab";

    [Header("Status")]
    public bool isSearching = false;
    public float searchTime = 0f;
    public List<string> foundPlayers = new List<string>();

    private NetworkManager networkManager;

    void Start()
    {
        networkManager = FindObjectOfType<NetworkManager>();
        if (networkManager == null)
        {
            Debug.LogError("NetworkManager não encontrado!");
        }
    }

    void Update()
    {
        if (isSearching)
        {
            searchTime += Time.deltaTime;
            
            if (searchTime >= searchTimeout)
            {
                OnMatchmakingTimeout();
            }
        }
    }

    public void StartMatchmaking()
    {
        if (isSearching) return;
        if (!networkManager.isConnected)
        {
            Debug.LogError("Não conectado ao servidor!");
            return;
        }

        Debug.Log("Iniciando busca por partida...");
        isSearching = true;
        searchTime = 0f;
        foundPlayers.Clear();

        // Enviar solicitação de matchmaking para o servidor
        SendMatchmakingRequest();
        
        // Notificar UI sobre início da busca
        OnMatchmakingStarted();
    }

    public void CancelMatchmaking()
    {
        if (!isSearching) return;

        Debug.Log("Cancelando busca por partida...");
        isSearching = false;
        searchTime = 0f;
        foundPlayers.Clear();

        // Enviar cancelamento para o servidor
        SendMatchmakingCancel();
        
        // Notificar UI sobre cancelamento
        OnMatchmakingCancelled();
    }

    private void SendMatchmakingRequest()
    {
        MatchmakingRequest request = new MatchmakingRequest
        {
            playerID = networkManager.playerID,
            gameMode = gameMode,
            preferredPlayerCount = preferredPlayerCount,
            region = "BR" // Região Brasil
        };

        NetworkMessage message = new NetworkMessage
        {
            type = "MATCHMAKING_REQUEST",
            playerID = networkManager.playerID,
            data = JsonUtility.ToJson(request)
        };

        // Enviar via NetworkManager
        Debug.Log($"Enviando solicitação de matchmaking: {JsonUtility.ToJson(message)}");
    }

    private void SendMatchmakingCancel()
    {
        NetworkMessage message = new NetworkMessage
        {
            type = "MATCHMAKING_CANCEL",
            playerID = networkManager.playerID
        };

        Debug.Log($"Cancelando matchmaking: {JsonUtility.ToJson(message)}");
    }

    // Métodos chamados pelo NetworkManager quando recebe mensagens do servidor
    public void OnMatchmakingUpdate(NetworkMessage message)
    {
        MatchmakingUpdate update = JsonUtility.FromJson<MatchmakingUpdate>(message.data);
        
        foundPlayers = update.foundPlayers;
        Debug.Log($"Matchmaking update: {foundPlayers.Count}/{preferredPlayerCount} jogadores encontrados");
        
        // Notificar UI sobre progresso
        OnMatchmakingProgress(foundPlayers.Count, preferredPlayerCount);
    }

    public void OnMatchFound(NetworkMessage message)
    {
        MatchFoundData matchData = JsonUtility.FromJson<MatchFoundData>(message.data);
        
        Debug.Log($"Partida encontrada! Sala: {matchData.roomID}");
        isSearching = false;
        
        // Entrar na sala da partida
        networkManager.JoinRoom(matchData.roomID);
        
        // Notificar UI sobre partida encontrada
        OnMatchmakingSuccess(matchData);
    }

    private void OnMatchmakingTimeout()
    {
        Debug.Log("Timeout na busca por partida!");
        isSearching = false;
        searchTime = 0f;
        foundPlayers.Clear();
        
        // Notificar UI sobre timeout
        OnMatchmakingFailed("Timeout - nenhuma partida encontrada");
    }

    // Eventos para notificar a UI
    private void OnMatchmakingStarted()
    {
        Debug.Log("Matchmaking iniciado - notificar UI");
        // Aqui você pode chamar eventos para atualizar a UI
    }

    private void OnMatchmakingProgress(int currentPlayers, int totalPlayers)
    {
        Debug.Log($"Progresso do matchmaking: {currentPlayers}/{totalPlayers}");
        // Atualizar barra de progresso na UI
    }

    private void OnMatchmakingSuccess(MatchFoundData matchData)
    {
        Debug.Log("Partida encontrada com sucesso!");
        // Fechar tela de matchmaking e preparar para o jogo
    }

    private void OnMatchmakingCancelled()
    {
        Debug.Log("Matchmaking cancelado pelo usuário");
        // Voltar ao menu principal
    }

    private void OnMatchmakingFailed(string reason)
    {
        Debug.Log($"Falha no matchmaking: {reason}");
        // Mostrar mensagem de erro na UI
    }
}

[System.Serializable]
public class MatchmakingRequest
{
    public string playerID;
    public string gameMode;
    public int preferredPlayerCount;
    public string region;
}

[System.Serializable]
public class MatchmakingUpdate
{
    public List<string> foundPlayers;
    public float estimatedWaitTime;
}

[System.Serializable]
public class MatchFoundData
{
    public string roomID;
    public List<string> playerIDs;
    public string gameMode;
    public string mapName;
}

