using UnityEngine;
using System.Collections.Generic;

public class NetworkManager : MonoBehaviour
{
    [Header("Network Settings")]
    public string serverURL = "ws://localhost:8080";
    public int maxPlayers = 6;
    public float tickRate = 20f;

    [Header("Game State")]
    public bool isConnected = false;
    public bool isHost = false;
    public string playerID;
    public string roomID;

    private Dictionary<string, PlayerData> connectedPlayers = new Dictionary<string, PlayerData>();
    private float lastTickTime;

    void Start()
    {
        // Gerar ID único para o jogador
        playerID = System.Guid.NewGuid().ToString();
        Debug.Log($"Player ID gerado: {playerID}");
    }

    void Update()
    {
        if (isConnected && Time.time - lastTickTime >= 1f / tickRate)
        {
            SendPlayerUpdate();
            lastTickTime = Time.time;
        }
    }

    public void ConnectToServer()
    {
        Debug.Log("Tentando conectar ao servidor...");
        // Implementar conexão WebSocket ou Unity Netcode
        // Por enquanto, simular conexão bem-sucedida
        isConnected = true;
        OnConnectedToServer();
    }

    public void CreateRoom()
    {
        if (!isConnected) return;

        roomID = System.Guid.NewGuid().ToString();
        isHost = true;
        Debug.Log($"Sala criada: {roomID}");
        
        // Enviar comando para criar sala no servidor
        SendMessage(new NetworkMessage
        {
            type = "CREATE_ROOM",
            playerID = playerID,
            roomID = roomID
        });
    }

    public void JoinRoom(string targetRoomID)
    {
        if (!isConnected) return;

        roomID = targetRoomID;
        Debug.Log($"Tentando entrar na sala: {roomID}");
        
        // Enviar comando para entrar na sala
        SendMessage(new NetworkMessage
        {
            type = "JOIN_ROOM",
            playerID = playerID,
            roomID = roomID
        });
    }

    public void SendPlayerUpdate()
    {
        if (!isConnected || string.IsNullOrEmpty(roomID)) return;

        // Obter dados do jogador local
        PlayerData localPlayer = GetLocalPlayerData();
        
        SendMessage(new NetworkMessage
        {
            type = "PLAYER_UPDATE",
            playerID = playerID,
            roomID = roomID,
            data = JsonUtility.ToJson(localPlayer)
        });
    }

    public void SendAttack(Vector3 position, Vector3 direction)
    {
        if (!isConnected) return;

        AttackData attackData = new AttackData
        {
            position = position,
            direction = direction,
            timestamp = Time.time
        };

        SendMessage(new NetworkMessage
        {
            type = "PLAYER_ATTACK",
            playerID = playerID,
            roomID = roomID,
            data = JsonUtility.ToJson(attackData)
        });
    }

    private void SendMessage(NetworkMessage message)
    {
        // Implementar envio via WebSocket ou Unity Netcode
        string json = JsonUtility.ToJson(message);
        Debug.Log($"Enviando mensagem: {json}");
    }

    private PlayerData GetLocalPlayerData()
    {
        // Obter dados do jogador local (posição, vida, etc.)
        return new PlayerData
        {
            playerID = playerID,
            position = transform.position,
            rotation = transform.rotation,
            health = 100,
            isAlive = true
        };
    }

    private void OnConnectedToServer()
    {
        Debug.Log("Conectado ao servidor!");
        // Notificar UI sobre conexão bem-sucedida
    }

    private void OnDisconnectedFromServer()
    {
        Debug.Log("Desconectado do servidor!");
        isConnected = false;
        isHost = false;
        roomID = "";
        connectedPlayers.Clear();
    }

    // Métodos para receber mensagens do servidor
    public void OnMessageReceived(string messageJson)
    {
        NetworkMessage message = JsonUtility.FromJson<NetworkMessage>(messageJson);
        
        switch (message.type)
        {
            case "PLAYER_JOINED":
                OnPlayerJoined(message);
                break;
            case "PLAYER_LEFT":
                OnPlayerLeft(message);
                break;
            case "PLAYER_UPDATE":
                OnPlayerUpdate(message);
                break;
            case "PLAYER_ATTACK":
                OnPlayerAttack(message);
                break;
            case "GAME_START":
                OnGameStart(message);
                break;
        }
    }

    private void OnPlayerJoined(NetworkMessage message)
    {
        Debug.Log($"Jogador entrou: {message.playerID}");
        // Adicionar jogador à lista e instanciar no jogo
    }

    private void OnPlayerLeft(NetworkMessage message)
    {
        Debug.Log($"Jogador saiu: {message.playerID}");
        // Remover jogador da lista e destruir no jogo
        if (connectedPlayers.ContainsKey(message.playerID))
        {
            connectedPlayers.Remove(message.playerID);
        }
    }

    private void OnPlayerUpdate(NetworkMessage message)
    {
        PlayerData playerData = JsonUtility.FromJson<PlayerData>(message.data);
        connectedPlayers[message.playerID] = playerData;
        // Atualizar posição e estado do jogador remoto
    }

    private void OnPlayerAttack(NetworkMessage message)
    {
        AttackData attackData = JsonUtility.FromJson<AttackData>(message.data);
        Debug.Log($"Jogador {message.playerID} atacou em {attackData.position}");
        // Processar ataque do jogador remoto
    }

    private void OnGameStart(NetworkMessage message)
    {
        Debug.Log("Jogo iniciado!");
        // Iniciar partida
    }
}

[System.Serializable]
public class NetworkMessage
{
    public string type;
    public string playerID;
    public string roomID;
    public string data;
}

[System.Serializable]
public class PlayerData
{
    public string playerID;
    public Vector3 position;
    public Quaternion rotation;
    public int health;
    public bool isAlive;
}

[System.Serializable]
public class AttackData
{
    public Vector3 position;
    public Vector3 direction;
    public float timestamp;
}

