using UnityEngine;

public class PlayerSync : MonoBehaviour
{
    [Header("Network Settings")]
    public bool isLocalPlayer = false;
    public string networkPlayerID;
    public float interpolationRate = 15f;
    public float extrapolationLimit = 0.5f;

    [Header("Sync Data")]
    public Vector3 networkPosition;
    public Quaternion networkRotation;
    public int networkHealth;
    public bool networkIsAlive;

    private Vector3 lastNetworkPosition;
    private Quaternion lastNetworkRotation;
    private float lastUpdateTime;
    private NetworkManager networkManager;

    void Start()
    {
        networkManager = FindObjectOfType<NetworkManager>();
        
        if (isLocalPlayer)
        {
            // Este é o jogador local - enviar atualizações
            networkPlayerID = networkManager.playerID;
        }
        else
        {
            // Este é um jogador remoto - receber atualizações
            // Desabilitar controles locais
            GetComponent<PlayerMovement>().enabled = false;
            GetComponent<PlayerAttack>().enabled = false;
        }
    }

    void Update()
    {
        if (isLocalPlayer)
        {
            // Enviar posição atual para outros jogadores
            SendPositionUpdate();
        }
        else
        {
            // Interpolar posição recebida da rede
            InterpolatePosition();
        }
    }

    void SendPositionUpdate()
    {
        if (networkManager == null || !networkManager.isConnected) return;

        // Verificar se a posição mudou significativamente
        if (Vector3.Distance(transform.position, lastNetworkPosition) > 0.1f ||
            Quaternion.Angle(transform.rotation, lastNetworkRotation) > 5f)
        {
            lastNetworkPosition = transform.position;
            lastNetworkRotation = transform.rotation;
            
            // Enviar atualização via NetworkManager
            networkManager.SendPlayerUpdate();
        }
    }

    void InterpolatePosition()
    {
        if (Time.time - lastUpdateTime > extrapolationLimit)
        {
            // Muito tempo sem atualizações - não extrapolar
            return;
        }

        // Interpolar suavemente para a posição de rede
        transform.position = Vector3.Lerp(transform.position, networkPosition, interpolationRate * Time.deltaTime);
        transform.rotation = Quaternion.Lerp(transform.rotation, networkRotation, interpolationRate * Time.deltaTime);
    }

    public void OnNetworkPositionUpdate(Vector3 position, Quaternion rotation, int health, bool isAlive)
    {
        if (isLocalPlayer) return; // Ignorar atualizações para o jogador local

        networkPosition = position;
        networkRotation = rotation;
        networkHealth = health;
        networkIsAlive = isAlive;
        lastUpdateTime = Time.time;

        // Atualizar componentes visuais
        UpdateVisuals();
    }

    private void UpdateVisuals()
    {
        // Atualizar barra de vida
        PlayerHealth healthComponent = GetComponent<PlayerHealth>();
        if (healthComponent != null)
        {
            healthComponent.SetHealth(networkHealth);
        }

        // Mostrar/esconder jogador baseado no estado de vida
        gameObject.SetActive(networkIsAlive);
    }

    public void OnNetworkAttack(Vector3 attackPosition, Vector3 attackDirection)
    {
        if (isLocalPlayer) return; // Ignorar ataques do próprio jogador

        // Reproduzir animação e efeitos de ataque
        PlayerAttack attackComponent = GetComponent<PlayerAttack>();
        if (attackComponent != null)
        {
            attackComponent.PlayAttackEffect(attackPosition, attackDirection);
        }
    }

    public void OnNetworkSuper(string superType, Vector3 superPosition)
    {
        if (isLocalPlayer) return;

        // Reproduzir efeitos da super habilidade
        PlayerSuperAbility superComponent = GetComponent<PlayerSuperAbility>();
        if (superComponent != null)
        {
            superComponent.PlaySuperEffect(superType, superPosition);
        }
    }

    // Método para configurar um jogador remoto
    public void SetupRemotePlayer(string playerID)
    {
        isLocalPlayer = false;
        networkPlayerID = playerID;
        
        // Desabilitar componentes de controle local
        PlayerMovement movement = GetComponent<PlayerMovement>();
        if (movement != null) movement.enabled = false;
        
        PlayerAttack attack = GetComponent<PlayerAttack>();
        if (attack != null) attack.enabled = false;
        
        // Adicionar identificação visual
        GameObject nameTag = new GameObject("NameTag");
        nameTag.transform.SetParent(transform);
        nameTag.transform.localPosition = Vector3.up * 2f;
        
        // Aqui você pode adicionar um Text component para mostrar o nome do jogador
        Debug.Log($"Jogador remoto configurado: {playerID}");
    }
}

