using UnityEngine;

public class PlayerSuperAbility : MonoBehaviour
{
    public float superCooldown = 10f;
    private float nextSuperTime = 0f;
    private int superCharge = 0;
    public int superChargeNeeded = 5; // Exemplo: precisa de 5 hits para carregar o Super

    void Update()
    {
        // Simulação de carregamento do Super (pode ser por dano causado)
        // if (Input.GetKeyDown(KeyCode.Space) && superCharge >= superChargeNeeded && Time.time >= nextSuperTime)
        // {
        //     ActivateSuper();
        //     superCharge = 0;
        //     nextSuperTime = Time.time + superCooldown;
        // }
    }

    public void AddSuperCharge(int amount)
    {
        superCharge += amount;
        Debug.Log($"Super carregado: {superCharge}/{superChargeNeeded}");
    }

    void ActivateSuper()
    {
        Debug.Log("Super Habilidade Ativada!");
        // Lógica da habilidade Super (ex: dano em área, cura, etc.)
    }
}

