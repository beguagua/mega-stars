using UnityEngine;

public class PowerUpCollector : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("PowerUp"))
        {
            Debug.Log("Power-up coletado!");
            // Aplica o efeito do power-up ao jogador
            Destroy(other.gameObject); // Destrói o power-up após a coleta
        }
    }
}

