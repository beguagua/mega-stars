using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public GameObject projectilePrefab;
    public Transform firePoint;
    public float attackCooldown = 0.5f;

    private float nextAttackTime = 0f;

    void Update()
    {
        if (Input.GetButton("Fire1") && Time.time >= nextAttackTime)
        {
            Attack();
            nextAttackTime = Time.time + attackCooldown;
        }
    }

    void Attack()
    {
        // Instancia o projétil no ponto de disparo
        // GameObject projectile = Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);
        // Adiciona lógica para o projétil se mover e causar dano
        Debug.Log("Player atacou!"); // Simulação de ataque
    }
}

