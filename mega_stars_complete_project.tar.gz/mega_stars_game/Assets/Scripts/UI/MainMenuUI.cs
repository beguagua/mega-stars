using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenuUI : MonoBehaviour
{
    [Header("UI Elements")]
    public Button playButton;
    public Button settingsButton;
    public Button exitButton;
    public GameObject settingsPanel;

    void Start()
    {
        // Configurar eventos dos botões
        playButton.onClick.AddListener(OnPlayButtonClicked);
        settingsButton.onClick.AddListener(OnSettingsButtonClicked);
        exitButton.onClick.AddListener(OnExitButtonClicked);
        
        // Garantir que o painel de configurações esteja fechado
        settingsPanel.SetActive(false);
    }

    void OnPlayButtonClicked()
    {
        Debug.Log("Iniciando jogo...");
        // Carregar a cena do jogo
        SceneManager.LoadScene("GameScene");
    }

    void OnSettingsButtonClicked()
    {
        Debug.Log("Abrindo configurações...");
        settingsPanel.SetActive(true);
    }

    void OnExitButtonClicked()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();
    }

    public void CloseSettings()
    {
        settingsPanel.SetActive(false);
    }
}

