using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BrawlerSelectionUI : MonoBehaviour
{
    [Header("Brawler Selection")]
    public Button[] brawlerButtons;
    public Image selectedBrawlerImage;
    public TextMeshProUGUI selectedBrawlerName;
    public TextMeshProUGUI selectedBrawlerDescription;
    public Button confirmButton;

    [Header("Brawler Data")]
    public BrawlerData[] availableBrawlers;

    private int selectedBrawlerIndex = 0;

    void Start()
    {
        // Configurar eventos dos botões
        for (int i = 0; i < brawlerButtons.Length; i++)
        {
            int index = i; // Capturar o índice para o closure
            brawlerButtons[i].onClick.AddListener(() => SelectBrawler(index));
        }

        confirmButton.onClick.AddListener(ConfirmSelection);

        // Selecionar o primeiro Brawler por padrão
        SelectBrawler(0);
    }

    void SelectBrawler(int index)
    {
        if (index < 0 || index >= availableBrawlers.Length) return;

        selectedBrawlerIndex = index;
        BrawlerData brawler = availableBrawlers[index];

        // Atualizar UI
        selectedBrawlerImage.sprite = brawler.sprite;
        selectedBrawlerName.text = brawler.name;
        selectedBrawlerDescription.text = brawler.description;

        // Destacar botão selecionado
        for (int i = 0; i < brawlerButtons.Length; i++)
        {
            brawlerButtons[i].GetComponent<Image>().color = (i == index) ? Color.yellow : Color.white;
        }

        Debug.Log($"Brawler selecionado: {brawler.name}");
    }

    void ConfirmSelection()
    {
        Debug.Log($"Confirmando seleção: {availableBrawlers[selectedBrawlerIndex].name}");
        // Salvar seleção e iniciar jogo
        PlayerPrefs.SetInt("SelectedBrawler", selectedBrawlerIndex);
        // Carregar cena do jogo ou voltar ao menu principal
    }
}

[System.Serializable]
public class BrawlerData
{
    public string name;
    public string description;
    public Sprite sprite;
    public int health;
    public int damage;
    public float attackSpeed;
}

