using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameHUD : MonoBehaviour
{
    [Header("Player Stats")]
    public Slider healthBar;
    public Slider ammoBar;
    public Slider superBar;
    public TextMeshProUGUI healthText;

    [Header("Game Info")]
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI timerText;
    public TextMeshProUGUI gemsText;

    [Header("Controls")]
    public Joystick movementJoystick;
    public Joystick aimJoystick;
    public Button attackButton;
    public Button superButton;

    void Start()
    {
        // Configurar eventos dos botões
        attackButton.onClick.AddListener(OnAttackButtonPressed);
        superButton.onClick.AddListener(OnSuperButtonPressed);
        
        // Inicializar valores
        UpdateHealthBar(100, 100);
        UpdateAmmoBar(3, 3);
        UpdateSuperBar(0, 100);
        UpdateScore(0);
        UpdateGems(0);
    }

    public void UpdateHealthBar(int currentHealth, int maxHealth)
    {
        healthBar.value = (float)currentHealth / maxHealth;
        healthText.text = $"{currentHealth}/{maxHealth}";
    }

    public void UpdateAmmoBar(int currentAmmo, int maxAmmo)
    {
        ammoBar.value = (float)currentAmmo / maxAmmo;
    }

    public void UpdateSuperBar(int currentSuper, int maxSuper)
    {
        superBar.value = (float)currentSuper / maxSuper;
        superButton.interactable = currentSuper >= maxSuper;
    }

    public void UpdateScore(int score)
    {
        scoreText.text = $"Score: {score}";
    }

    public void UpdateTimer(float timeRemaining)
    {
        int minutes = Mathf.FloorToInt(timeRemaining / 60);
        int seconds = Mathf.FloorToInt(timeRemaining % 60);
        timerText.text = $"{minutes:00}:{seconds:00}";
    }

    public void UpdateGems(int gems)
    {
        gemsText.text = $"Gems: {gems}/10";
    }

    void OnAttackButtonPressed()
    {
        Debug.Log("Botão de ataque pressionado!");
        // Enviar evento para o sistema de ataque
    }

    void OnSuperButtonPressed()
    {
        Debug.Log("Botão de Super pressionado!");
        // Enviar evento para o sistema de Super
    }
}

