# Guia de Publicação - Apple App Store

## Pré-requisitos

### Apple Developer Program
- **Custo:** $99/ano (USD)
- **Requisitos:** Apple ID, cartão de crédito válido
- **Verificação:** Pode levar 24-48 horas
- **Renovação:** Anual obrigatória

### Ferramentas Necessárias
- **Xcode:** Versão mais recente (macOS obrigatório)
- **App Store Connect:** Portal de desenvolvedor
- **TestFlight:** Para testes beta
- **Transporter:** Para upload de builds

## Preparação do App

### 1. Informações Básicas
- **Nome do App:** Mega Stars
- **Subtitle:** Arena Battle Game
- **Categoria Primária:** Games > Action
- **Categoria Secundária:** Games > Strategy
- **Classificação:** 4+ (sem conteúdo questionável)

### 2. Assets Visuais Necessários

#### Ícone do App
- **Tamanhos Necessários:**
  - 1024x1024 (App Store)
  - 180x180 (iPhone)
  - 167x167 (iPad Pro)
  - 152x152 (iPad)
  - 120x120 (iPhone retina)
- **Formato:** PNG sem transparência
- **Requisitos:** Bordas quadradas (iOS adiciona automaticamente)

#### Screenshots
**iPhone 6.7" (iPhone 14 Pro Max, 13 Pro Max, 12 Pro Max)**
- Tamanho: 1290x2796 ou 2796x1290
- Mínimo: 3 screenshots
- Máximo: 10 screenshots

**iPhone 6.5" (iPhone 11 Pro Max, XS Max)**
- Tamanho: 1242x2688 ou 2688x1242
- Obrigatório se não tiver 6.7"

**iPhone 5.5" (iPhone 8 Plus, 7 Plus, 6s Plus)**
- Tamanho: 1242x2208 ou 2208x1242
- Obrigatório para compatibilidade

**iPad Pro (6ª geração) 12.9"**
- Tamanho: 2048x2732 ou 2732x2048
- Mínimo: 3 screenshots

**iPad Pro (2ª geração) 12.9"**
- Tamanho: 2048x2732 ou 2732x2048
- Obrigatório se não tiver 6ª geração

### 3. Descrição da App Store

#### Nome (30 caracteres)
"Mega Stars"

#### Subtitle (30 caracteres)
"Arena Battle Game"

#### Palavras-chave (100 caracteres)
"arena,battle,multiplayer,action,strategy,heroes,combat,online,pvp,team"

#### Descrição (4000 caracteres)
```
🌟 MEGA STARS - THE ULTIMATE ARENA BATTLE EXPERIENCE! 🌟

Step into the vibrant world of Mega Stars, where unique heroes clash in epic arena battles! Inspired by the best in the genre, Mega Stars delivers intense action, deep strategy, and guaranteed fun for players of all skill levels.

🎮 KEY FEATURES:

⚔️ DYNAMIC COMBAT
• Fluid and responsive combat system
• Unique attacks for each character
• Devastating super abilities
• Intuitive controls optimized for mobile

🏆 EXCITING GAME MODES
• Gem Grab: Collect 10 gems and hold for 15 seconds
• More modes coming soon!

👥 ONLINE MULTIPLAYER
• Real-time 3v3 matches
• Smart matchmaking
• Play with friends or make new ones

🌟 UNIQUE HEROES
• Sharpshooter: Long-range combat specialist
• Tank: Tough and powerful in close combat
• Support: Heals allies and provides tactical advantages
• More heroes added regularly!

🎨 STUNNING GRAPHICS
• Colorful and vibrant art style
• Spectacular visual effects
• Smooth animations
• Optimized for all iOS devices

🚀 TECHNICAL FEATURES
• Free-to-play with customization options
• Offline support for training
• Regular updates with new content
• Compatible with iOS 12.0+

📱 MOBILE OPTIMIZED
• Intuitive interface
• Responsive controls
• Low battery consumption
• Works on older devices

Download now and join the arena battle revolution! Prove you have what it takes to become a true MEGA STAR!

🔥 Coming Soon:
• New heroes
• New game modes
• Clan system
• Competitive tournaments

Follow us on social media for the latest updates!

Privacy Policy: [URL]
Terms of Service: [URL]
```

### 4. Configurações de Distribuição

#### Disponibilidade
- **Países Iniciais:** Brasil, Estados Unidos
- **Expansão:** Global após validação inicial
- **Preço:** Gratuito (Freemium)

#### Classificação Etária
- **Rating:** 4+ (No Objectionable Content)
- **Justificativa:** Jogo de ação cartoon sem violência realística

## App Store Review Guidelines

### Compliance Checklist

#### Design
- ✅ Interface nativa iOS
- ✅ Suporte a diferentes tamanhos de tela
- ✅ Orientação portrait e landscape
- ✅ Navegação intuitiva
- ✅ Feedback visual adequado

#### Funcionalidade
- ✅ App funciona conforme descrito
- ✅ Sem crashes ou bugs críticos
- ✅ Performance adequada em dispositivos suportados
- ✅ Funcionalidades offline quando aplicável
- ✅ Integração adequada com iOS

#### Conteúdo
- ✅ Conteúdo apropriado para classificação 4+
- ✅ Sem violência excessiva ou realística
- ✅ Sem conteúdo sexual ou adulto
- ✅ Sem linguagem ofensiva
- ✅ Respeito a direitos autorais

#### Privacidade
- ✅ Política de privacidade clara e acessível
- ✅ Consentimento para coleta de dados
- ✅ Transparência no uso de dados
- ✅ Compliance com COPPA (menores de 13 anos)

### Recursos Específicos iOS

#### Game Center Integration
```swift
// Exemplo de integração com Game Center
import GameKit

class GameCenterManager {
    func authenticatePlayer() {
        let localPlayer = GKLocalPlayer.local
        localPlayer.authenticateHandler = { viewController, error in
            if let vc = viewController {
                // Apresentar tela de login
                self.presentViewController(vc)
            } else if localPlayer.isAuthenticated {
                // Jogador autenticado
                self.enableGameCenterFeatures()
            }
        }
    }
}
```

#### Haptic Feedback
```swift
// Implementar feedback tátil
import UIKit

class HapticManager {
    func lightImpact() {
        let impactFeedback = UIImpactFeedbackGenerator(style: .light)
        impactFeedback.impactOccurred()
    }
    
    func mediumImpact() {
        let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
        impactFeedback.impactOccurred()
    }
}
```

## Processo de Submissão

### 1. Preparação do Build
```bash
# Configurações de build no Unity
# Player Settings > iOS
# - Bundle Identifier: com.megastarsstudio.megastars
# - Version: 1.0.0
# - Build: 1
# - Minimum iOS Version: 12.0
# - Target Device: Universal
# - Architecture: ARM64
```

### 2. Xcode Configuration
- Configurar signing certificates
- Verificar bundle identifier
- Configurar capabilities necessárias
- Testar em dispositivos reais

### 3. Archive e Upload
- Archive no Xcode
- Validar antes do upload
- Upload via Xcode ou Transporter
- Aguardar processamento (pode levar horas)

### 4. App Store Connect
- Selecionar build processado
- Preencher metadados
- Adicionar screenshots
- Configurar preços e disponibilidade
- Submeter para review

## TestFlight (Beta Testing)

### Configuração
- Upload de build via Xcode
- Configurar informações de teste
- Adicionar testadores internos (até 100)
- Configurar testadores externos (até 10.000)

### Processo de Teste
- Testadores recebem convite via email
- Download via app TestFlight
- Coleta de feedback e crash reports
- Iteração baseada em feedback

## Cronograma de Submissão

### Semana 1: Preparação
- Configurar conta Apple Developer
- Preparar assets visuais
- Finalizar build iOS

### Semana 2: Testes Internos
- Upload para TestFlight
- Testes com equipe interna
- Correção de bugs iOS-específicos

### Semana 3: Beta Externo
- Convite para testadores beta
- Coleta de feedback
- Implementação de melhorias

### Semana 4: Submissão
- Finalização de metadados
- Upload do build final
- Submissão para App Store Review

### Semana 5: Review Process
- Aguardar review da Apple (1-7 dias)
- Responder a possíveis rejeições
- Resubmissão se necessário

### Semana 6: Lançamento
- Aprovação da Apple
- Configurar data de lançamento
- Lançamento oficial

## Pós-Lançamento

### Monitoramento
- App Store Connect Analytics
- Crash reports via Xcode
- Reviews e ratings
- Performance metrics

### Atualizações
- Correções de bugs
- Novos recursos
- Melhorias de performance
- Compliance com novas versões iOS

## Monetização (Futuro)

### In-App Purchases
- Configurar produtos no App Store Connect
- Implementar StoreKit 2
- Validação de receipts server-side
- Suporte a Family Sharing

### Subscription (Passe de Batalha)
- Configurar auto-renewable subscriptions
- Implementar subscription management
- Oferecer período de teste gratuito
- Compliance com subscription guidelines

## Rejeições Comuns e Como Evitar

### Guideline 2.1 - App Completeness
- ✅ App totalmente funcional
- ✅ Sem placeholder content
- ✅ Todas as funcionalidades implementadas

### Guideline 4.3 - Spam
- ✅ App único e diferenciado
- ✅ Não cópia de outros apps
- ✅ Valor único para usuários

### Guideline 5.1.1 - Privacy
- ✅ Política de privacidade acessível
- ✅ Descrição clara de coleta de dados
- ✅ Consentimento adequado

