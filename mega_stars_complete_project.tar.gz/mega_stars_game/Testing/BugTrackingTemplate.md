# Template de Rastreamento de Bugs - Mega Stars

## Informações do Bug

### ID do Bug: [AUTO-GENERATED]
### Data de Descoberta: [DD/MM/YYYY]
### Reportado por: [NOME]
### Plataforma: [Android/iOS/PS4/PS5/PC]
### Versão do Build: [X.X.X]

## Classificação

### Severidade:
- [ ] Crítica (Crash, perda de dados, impossível jogar)
- [ ] Alta (Funcionalidade principal quebrada)
- [ ] Média (Funcionalidade secundária afetada)
- [ ] Baixa (Problema cosmético ou menor)

### Prioridade:
- [ ] P1 - Corrigir imediatamente
- [ ] P2 - Corrigir antes do release
- [ ] P3 - Corrigir em próxima versão
- [ ] P4 - Backlog

### Categoria:
- [ ] Gameplay
- [ ] UI/UX
- [ ] Performance
- [ ] Rede/Multiplayer
- [ ] Audio
- [ ] Gráficos
- [ ] Controles
- [ ] Progressão

## Descrição do Problema

### Resumo:
[Descrição breve e clara do problema]

### Descrição Detalhada:
[Explicação completa do que está acontecendo]

### Comportamento Esperado:
[O que deveria acontecer]

### Comportamento Atual:
[O que está acontecendo atualmente]

## Reprodução

### Passos para Reproduzir:
1. [Passo 1]
2. [Passo 2]
3. [Passo 3]
...

### Frequência:
- [ ] Sempre (100%)
- [ ] Frequente (75-99%)
- [ ] Ocasional (25-74%)
- [ ] Raro (1-24%)
- [ ] Não reproduzível

### Condições Específicas:
- [ ] Dispositivo específico
- [ ] Configuração específica
- [ ] Momento específico do jogo
- [ ] Ação específica do usuário

## Informações Técnicas

### Especificações do Dispositivo:
- **Modelo:** [Ex: iPhone 13, Samsung Galaxy S21]
- **OS:** [Ex: iOS 15.1, Android 12]
- **RAM:** [Ex: 6GB]
- **Armazenamento Disponível:** [Ex: 32GB]

### Logs/Stack Trace:
```
[Colar logs relevantes aqui]
```

### Screenshots/Videos:
- [ ] Screenshot anexado
- [ ] Video anexado
- [ ] Arquivo de log anexado

## Impacto

### Impacto no Usuário:
- [ ] Impede progressão no jogo
- [ ] Causa frustração significativa
- [ ] Problema menor/cosmético
- [ ] Não afeta experiência do usuário

### Impacto no Negócio:
- [ ] Pode afetar reviews/ratings
- [ ] Pode afetar retenção de usuários
- [ ] Pode afetar monetização
- [ ] Impacto mínimo

## Investigação

### Possível Causa:
[Hipótese sobre a causa do problema]

### Componentes Afetados:
- [ ] PlayerMovement.cs
- [ ] NetworkManager.cs
- [ ] GameHUD.cs
- [ ] [Outro componente]

### Workaround Disponível:
- [ ] Sim: [Descrever workaround]
- [ ] Não

## Resolução

### Status:
- [ ] Aberto
- [ ] Em Investigação
- [ ] Em Desenvolvimento
- [ ] Em Teste
- [ ] Resolvido
- [ ] Fechado
- [ ] Não será corrigido

### Assignado para: [DESENVOLVEDOR]
### Data de Resolução: [DD/MM/YYYY]
### Build de Correção: [X.X.X]

### Solução Implementada:
[Descrição da correção aplicada]

### Testes de Verificação:
- [ ] Teste manual realizado
- [ ] Teste automatizado criado
- [ ] Teste em múltiplas plataformas
- [ ] Teste de regressão realizado

## Notas Adicionais

### Comentários:
[Qualquer informação adicional relevante]

### Bugs Relacionados:
- [ID do bug relacionado 1]
- [ID do bug relacionado 2]

### Referências:
- [Links para documentação relevante]
- [Links para discussões relacionadas]

---

## Exemplo de Bug Preenchido

### ID do Bug: BUG-001
### Data de Descoberta: 15/03/2024
### Reportado por: João Silva
### Plataforma: Android
### Versão do Build: 1.0.0-beta

## Classificação
- [x] Severidade: Alta
- [x] Prioridade: P1
- [x] Categoria: Multiplayer

## Descrição do Problema
### Resumo: Jogador não consegue se conectar ao servidor em dispositivos Android

### Comportamento Esperado: Jogador deve conectar automaticamente ao servidor ao iniciar o jogo

### Comportamento Atual: Tela de "Conectando..." fica infinita, nunca conecta

## Reprodução
### Passos para Reproduzir:
1. Abrir o jogo em dispositivo Android
2. Aguardar tela de carregamento
3. Observar tela de "Conectando ao servidor..."

### Frequência: Sempre (100%)

## Informações Técnicas
### Especificações do Dispositivo:
- **Modelo:** Samsung Galaxy A32
- **OS:** Android 11
- **RAM:** 4GB

### Logs:
```
NetworkManager: Tentando conectar a ws://localhost:8080
WebSocket: Connection failed - Network unreachable
```

## Resolução
### Status: Em Desenvolvimento
### Assignado para: Maria Santos
### Solução Proposta: Alterar URL do servidor de localhost para endereço público

