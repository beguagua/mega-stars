
# Documento de Design do Jogo (GDD) - Mega Stars

## 1. Visão Geral do Jogo

**Título do Jogo**: Mega Stars

**Gênero**: Shooter de arena multiplayer top-down com elementos de MOBA e Battle Royale.

**Plataformas Iniciais**: Android, PC (para desenvolvimento e testes).

**Público-Alvo**: Jogadores casuais e competitivos que apreciam jogos de ação rápida e multiplayer.

**Premissa**: Mega Stars é um jogo de tiro de arena vibrante e dinâmico onde jogadores controlam personagens únicos, cada um com habilidades distintas, em batalhas rápidas contra outros jogadores. O objetivo é oferecer uma experiência de jogo acessível, mas com profundidade estratégica, inspirada no sucesso de Brawl Stars.

## 2. Mecânicas de Gameplay

### 2.1. Controle e Movimentação
*   **Controle**: Joystick virtual na tela para movimentação (mobile) ou teclado/mouse (PC).
*   **Mover e Atirar**: Os jogadores podem se mover e atirar simultaneamente. O tiro pode ser manual (arrastar para mirar) ou automático (tocar para atirar no inimigo mais próximo).
*   **Interação com o Ambiente**: Personagens podem se esconder em arbustos (ficando invisíveis para inimigos fora do arbusto) e usar paredes como cobertura contra ataques.

### 2.2. Sistema de Combate
*   **Ataques Básicos**: Cada Brawler possui um ataque básico com características únicas (alcance, dano, área de efeito). Os ataques consomem uma barra de munição que se regenera automaticamente.
*   **Super Habilidade**: Uma habilidade especial e poderosa que é carregada ao causar dano aos inimigos. O uso estratégico do Super é crucial para o sucesso.
*   **Pontos de Vida (HP)**: Cada Brawler tem uma quantidade de HP. Ao chegar a zero, o Brawler é nocauteado e reaparece após um curto período (em modos de equipe).

### 2.3. Personagens (Brawlers)
*   **Variedade**: Cada Brawler terá um design visual único, conjunto de habilidades (ataque básico e Super) e estatísticas (HP, dano, velocidade de movimento).
*   **Brawlers Iniciais (MVP)**:
    *   **Brawler 1 (Atirador)**: Ataque de longo alcance, Super que causa dano em área.
    *   **Brawler 2 (Tanque)**: Alto HP, ataque de curto alcance, Super que o torna temporariamente invulnerável.
    *   **Brawler 3 (Suporte)**: Ataque de médio alcance, Super que cura aliados.

## 3. Modos de Jogo (MVP)

### 3.1. Gem Grab (Pega-Gemas)
*   **Objetivo**: Duas equipes de 3 jogadores competem para coletar 10 gemas que surgem de uma mina central. A equipe que coletar e manter 10 gemas por 15 segundos vence.
*   **Mecânicas Específicas**: Gemas são derrubadas quando um jogador é nocauteado. Um contador regressivo aparece quando uma equipe atinge 10 gemas.

## 4. Progressão

### 4.1. Desbloqueio de Brawlers
*   Brawlers podem ser desbloqueados através de um sistema de caixas (loot boxes) ou por progressão em um caminho de troféus.

### 4.2. Power-ups
*   Em modos específicos (como Showdown, se implementado futuramente), power-ups podem ser coletados para aumentar temporariamente o dano e HP do Brawler.

## 5. Interface de Usuário (UI)

### 5.1. Telas Principais
*   **Tela Inicial**: Acesso rápido a modos de jogo, seleção de Brawler, loja e configurações.
*   **Seleção de Brawler**: Permite ao jogador escolher seu Brawler antes de entrar em uma partida.
*   **HUD (Heads-Up Display)**: Exibe HP, munição, status do Super, placar do jogo e temporizador durante as partidas.

## 6. Aspectos Técnicos (MVP)

### 6.1. Motor de Jogo
*   Unity 3D.

### 6.2. Rede (Multiplayer)
*   Solução de rede baseada em Unity (UNET ou Photon, a ser definida) para partidas em tempo real.

### 6.3. Arte e Áudio
*   **Estilo de Arte**: Cartunesco, vibrante e colorido, similar ao Brawl Stars.
*   **Assets Iniciais**: Sprites 2D para Brawlers, texturas para mapas, efeitos de partículas para ataques e Supers. Música de fundo e efeitos sonoros básicos.

## 7. Plano de Desenvolvimento (MVP)

1.  **Configuração do Projeto Unity**: Criação do projeto, importação de pacotes essenciais.
2.  **Mecânicas Core**: Implementação de movimentação, sistema de ataque básico e Super.
3.  **Brawlers Iniciais**: Criação dos 3 Brawlers com suas habilidades.
4.  **Modo Gem Grab**: Implementação da lógica do modo de jogo.
5.  **Multiplayer Básico**: Sincronização de movimento e ataques entre jogadores.
6.  **UI Essencial**: Menus e HUD.
7.  **Testes Internos**: Testes de funcionalidade e balanceamento.

## 8. Considerações Futuras

*   **Novos Modos de Jogo**: Brawl Ball, Heist, Showdown, etc.
*   **Mais Brawlers**: Expansão do elenco de personagens.
*   **Sistema de Progressão Avançado**: Troféus, ranqueamento, Star Powers, Gadgets, Passe de Batalha.
*   **Funcionalidades Sociais**: Listas de amigos, clubes, chat.
*   **Otimização e Publicação**: Otimização para iOS e PlayStation, e processos de submissão às lojas.

